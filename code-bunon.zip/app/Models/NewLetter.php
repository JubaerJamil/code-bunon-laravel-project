<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NewLetter extends Model
{
    //
}
