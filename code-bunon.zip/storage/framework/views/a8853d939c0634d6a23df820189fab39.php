

<?php $__env->startSection('backend_content'); ?>

    <div class="my-4 row">
        <div class="col-lg-12 col-md-12 col-12">
            <div class="card">
                <!-- Card header -->
                <div class="pb-0 card-header">
                    <div class="d-lg-flex">
                        <div>
                            <h5 class="mb-0">Client Message </h5>
                            <p class="mb-0 text-sm">
                            </p>
                        </div>
                        <div class="my-auto mt-4 ms-auto mt-lg-0">
                        </div>
                    </div>
                </div>
                <hr>
                <div class="px-0 pb-0 card-body">
                    <div class="table-responsive">
                        <table class="table table-flush" id="products-list">
                            <thead class="thead-light">
                                <tr>
                                    <th class="fs-6" style="color: black">Sl. No.</th>
                                    <th class="fs-6" style="color: black">Message Date/Time</th>
                                    <th class="fs-6" style="color: black">Client Name</th>
                                    <th class="fs-6" style="color: black">E-mail</th>
                                    <th class="fs-6" style="color: black">Phone Number</th>
                                    <th class="fs-6" style="color: black">City</th>
                                    <th class="fs-6" style="color: black">Country</th>
                                    <th class="fs-6" style="color: black">Subject</th>
                                    <th class="fs-6" style="color: black">Message</th>
                                    <th class="fs-6" style="color: black">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $clientMessage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>

                                        <td>
                                            <?php echo e($index + 1); ?>

                                        </td>

                                        <td><?php echo e(date('d-M-Y / h:i A', strtotime($item->created_at))); ?></td>

                                        <td><?php echo e($item->name); ?></td>


                                        <td>
                                            <?php echo e($item->email); ?>

                                        </td>

                                        <td><?php echo e($item->phone); ?></td>

                                        <td><?php echo e($item->city); ?></td>

                                        <td><?php echo e($item->country); ?></td>

                                        <td><?php echo e($item->subject); ?></td>
                                        <td><textarea class="form-control" cols="60" rows="2"><?php echo e($item->message); ?></textarea></td>

                                        <td class="text-sm">
                                            <a onclick="return confirm('Are you sure Delete?')"
                                                href="<?php echo e(Route('contact_Message_Delete', $item->id)); ?>" data-bs-toggle="tooltip"
                                                data-bs-original-title="Delete product">
                                                <i class="fa-solid fa-trash-can fs-5 text-danger"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-sm" colspan="3">Data Not Found!!</td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/backend/contactMessage/index.blade.php ENDPATH**/ ?>