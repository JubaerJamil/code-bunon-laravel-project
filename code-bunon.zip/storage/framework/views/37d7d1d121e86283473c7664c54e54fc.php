
<?php $__env->startSection('backend_title', 'Admin Brand Create'); ?>

<?php $__env->startSection('backend_content'); ?>

    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-lg-offset-5">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(Route('slider_Create')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h5 class="font-weight-bolder">Slider Create</h5>
                        <div class="row">

                            <div class="col-lg-6 col-md-6 col-sm-12 mb-2">
                                <label>Title</label>
                                <input class="form-control" type="text" name="title" placeholder=""
                                    value="<?php echo e(old('title')); ?>" />
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="form-text text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12 mb-2">
                                <label class="form-label" for="headline">Slider Headline</label>
                                <input type="text" class="form-control" id="headline" placeholder="Enter Headline"
                                    name="headline" required />
                                <?php $__errorArgs = ['headline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-lg-12 col-md-6 col-sm-12 mb-2">
                                <label class="form-label">Slider Content</label>
                                <textarea name="content" class="form-control" id="myContent" cols="35" rows="5"></textarea>
                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="col-lg-6 col-md-6 col-sm-12 mb-2">
                                <label class="form-label" for="ecommerce-category-image">Slider Image</label>
                                <input class="form-control" name="image" type="file" oninput="previewImage(this)"
                                    required>
                                <p>Best image size for perfect view 1170px * 550px</p>
                                <img src="" alt="Image Preview" id="img" class="mt-3 rounded float-start"
                                    style="display: none; width:320px; max-height: 200px; border: none; outline: none; background: transparent;">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div>
                                    <label>Status</label>
                                </div>
                                <div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status" id="status1"
                                            value="1">
                                        <label class="form-check-label" for="status1">Active</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status" id="status0"
                                            value="0">
                                        <label class="form-check-label" for="status0">Inactive</label>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="mt-2">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <a href="<?php echo e(route('slider_List')); ?>" class="btn btn-info">Return List</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('beackend_scripts'); ?>

    <script>
        function previewImage(input) {
            const img = document.getElementById('img');

            if (input.files && input.files[0]) {
                img.src = window.URL.createObjectURL(input.files[0]);
                img.style.display = 'block'; // Show the image
            } else {
                img.style.display = 'none'; // Hide the image if no file selected
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/backend/slider/create.blade.php ENDPATH**/ ?>