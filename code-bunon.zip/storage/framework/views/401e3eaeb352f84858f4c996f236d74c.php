<footer class="footer pt-3  ">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">
            <div class="footer-copyright">Copyright &copy; <?php echo date('Y'); ?> <a href="https://codebunon.com" class="text-secondary" target="_blank"><span class="text-info">Code Bunon</span></a>. All Rights Reserved.</p></div>
        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                <li class="nav-item">
                    <a href="https://codebunon.com" class="nav-link text-xs text-muted" target="_blank">Code Bunon</a>
                </li>
                <li class="nav-item">
                    <a href="https://codebunon.com/about" class="nav-link text-xs text-muted" target="_blank">About Us</a>
                </li>
            </ul>
        </div>
    </div>
</footer>
<?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/backend/layout/footer.blade.php ENDPATH**/ ?>