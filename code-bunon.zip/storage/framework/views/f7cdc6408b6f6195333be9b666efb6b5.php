<?php $__env->startSection('forntend_content'); ?>

<div class="inner-banner">
    <div class="container">
        <div class="inner-title text-center">
            <h3>Team</h3>
            <ul>
                <li>
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li>
                    <i class="bx bx-chevrons-right"></i>
                </li>
                <li>Team</li>
            </ul>
        </div>
    </div>
    <div class="inner-shape">
        <img src="frontend-asset/images/shape/inner-shape.png" alt="Images">
    </div>
</div>
<div class="team-area pt-100 pb-70">
    <div class="container">
        <div class="section-title text-center">
            <span class="sp-color2">Our Team</span>
            <h2>Our Team Members</h2>
        </div>
        <div class="row pt-45">
            <div class="col-lg-4 col-md-6">
                <div class="team-card">
                    <img src="frontend-asset/images/team/code_bunon_team-2.png" alt="Team Images">
                    
                    <div class="content">
                        <h3>Jubaer Hossen Jamil</h3>
                        <span>PHP & Laravel Developer</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="team-card">
                    <img src="frontend-asset/images/team/code_bunon_team.png" alt="Team Images">
                    
                    <div class="content">
                        <h3>Md. Tarequl Islam Menon</h3>
                        <span>Wordpress & Shopify Developer</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="team-card">
                    <img src="frontend-asset/images/team/code_bunon_team_3.jpg" alt="Team Images">
                    
                    <div class="content">
                        <h3>Dipandar Biswas</h3>
                        <span>PHP & Laravel Developer</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="team-card">
                    <img src="frontend-asset/images/team/team-img4.jpg" alt="Team Images">
                    
                    <div class="content">
                        <h3>Tom Shumate</h3>
                        <span>Founder</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="team-card">
                    <img src="frontend-asset/images/team/team-img5.jpg" alt="Team Images">
                    
                    <div class="content">
                        <h3>Michael Evens</h3>
                        <span>Team Leader</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="team-card">
                    <img src="frontend-asset/images/team/team-img6.jpg" alt="Team Images">
                    
                    <div class="content">
                        <h3>Carrie Horton</h3>
                        <span>Sales Manager</span>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/frontend/team.blade.php ENDPATH**/ ?>