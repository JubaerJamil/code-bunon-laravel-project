<div class="brand-area ptb-100">
    <div class="container">
        <div class="brand-slider owl-carousel owl-theme">
            <div class="brand-item">
                <img src="frontend-asset/images/brand-logo/brand-logo1.png" class="brand-logo-one" alt="Images">
                <img src="frontend-asset/images/brand-logo/brand-style1.png" class="brand-logo-two" alt="Images">
            </div>
            <div class="brand-item">
                <img src="frontend-asset/images/brand-logo/brand-logo2.png" class="brand-logo-one" alt="Images">
                <img src="frontend-asset/images/brand-logo/brand-style2.png" class="brand-logo-two" alt="Images">
            </div>
            <div class="brand-item">
                <img src="frontend-asset/images/brand-logo/brand-logo3.png" class="brand-logo-one" alt="Images">
                <img src="frontend-asset/images/brand-logo/brand-style3.png" class="brand-logo-two" alt="Images">
            </div>
            <div class="brand-item">
                <img src="frontend-asset/images/brand-logo/brand-logo4.png" class="brand-logo-one" alt="Images">
                <img src="frontend-asset/images/brand-logo/brand-style4.png" class="brand-logo-two" alt="Images">
            </div>
            <div class="brand-item">
                <img src="frontend-asset/images/brand-logo/brand-logo5.png" class="brand-logo-one" alt="Images">
                <img src="frontend-asset/images/brand-logo/brand-style5.png" class="brand-logo-two" alt="Images">
            </div>
            <div class="brand-item">
                <img src="frontend-asset/images/brand-logo/brand-logo3.png" class="brand-logo-one" alt="Images">
                <img src="frontend-asset/images/brand-logo/brand-style3.png" class="brand-logo-two" alt="Images">
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/frontend/home/brand-area.blade.php ENDPATH**/ ?>