<?php $__env->startSection('forntend_content'); ?>
    <div class="inner-banner">
        <div class="container">
            <div class="inner-title text-center">
                <h3>Our Services</h3>
                <ul>
                    <li>
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li>
                        <i class="bx bx-chevrons-right"></i>
                    </li>
                    <li>Our Services</li>
                </ul>
            </div>
        </div>
        <div class="inner-shape">
            <img src="assets/images/shape/inner-shape.png" alt="Images">
        </div>
    </div>
    <section class="services-style-area pt-100 pb-70">
        <div class="container">
            <div class="section-title text-center">
                <span class="sp-color2">Our Services</span>
                <h2>We Provide a Wide Variety of It Services</h2>
                <p class="margin-auto">
                    Welcome to Code Bunon, where we are committed to delivering exceptional solutions carefully crafted to
                    meet your unique needs.
                    Our wide range of services guarantees that we can meet all your requirements, regardless of the scale or
                    complexity of your project.
                </p>
            </div>
            <div class="row pt-45">
                <?php $__currentLoopData = $allService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6">
                        <a href="<?php echo e(Route('service_content', $service->slug)); ?>">
                            <div class="services-card services-style-bg">
                                <i class="<?php echo e($service->icon); ?>"></i>
                                <h3>
                                    <p style="font-weight: 600"><?php echo e($service->title); ?></p>
                                </h3>

                                <p class="mb-0">
                                    <?php echo e(\Illuminate\Support\Str::limit(strip_tags($service->content), 80)); ?>...<br></p>

                                <span class="learn-btn">Learn More <i class="bx bx-chevron-right"></i></span>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/frontend/service.blade.php ENDPATH**/ ?>