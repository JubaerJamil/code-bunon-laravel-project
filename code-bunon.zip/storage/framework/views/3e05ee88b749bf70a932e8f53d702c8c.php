<header class="top-header top-header-bg">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7 col-md-6">
                <div class="top-head-left">
                    <div class="top-contact">
                        <h3>Support By : <a href="tel:88 01710-855-446">+88 01710-855-446</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-6">
                <div class="top-header-right">
                    <div class="top-header-social">
                        <ul>
                            <li>
                                <a href="https://www.facebook.com/codebunon" target="_blank">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                            
                            <li>
                                <a href="https://www.linkedin.com/" target="_blank">
                                    <i class="bx bxl-linkedin-square"></i>
                                </a>
                            </li>
                            
                        </ul>
                    </div>
                    <div class="language-list">
                        <select class="language-list-item">
                            <option>English</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>