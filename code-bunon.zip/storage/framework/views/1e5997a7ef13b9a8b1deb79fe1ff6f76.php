<div class="navbar-area">

    <div class="mobile-nav">
        <a href="<?php echo e(url('/')); ?>" class="logo">
            <img src="<?php echo e(asset('frontend-asset/images/logos/Code_Bunon_logo.png')); ?>" class="logo-one" alt="Logo">
            <img src="<?php echo e(asset('frontend-asset/images/logos/Code_Bunon_logo.png')); ?>" class="logo-two" alt="Logo">
        </a>
    </div>

    <div class="main-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light ">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('frontend-asset/images/logos/Code_Bunon_logo.png')); ?>" class="logo-one" alt="Logo">
                    <img src="<?php echo e(asset('frontend-asset/images/logos/Code_Bunon_logo.png')); ?>" class="logo-two" alt="Logo">
                </a>
                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav m-auto">
                        <li class="nav-item">
                            <a href="<?php echo e(url('/')); ?>" class="nav-link <?php echo e(Request::route()->named('home_page') ? 'active' : ''); ?>">
                                Home
                            </a>
                            
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(Route('service-page')); ?>" class="nav-link 
                            <?php echo e(Request::route()->named('service-page') ? 'active' : ''); ?>

                             <?php echo e(Request::route()->named('service_content') ? 'active' : ''); ?>

                             ">
                                Services
                                <i class="bx bx-caret-down"></i>
                            </a>
                            <ul class="dropdown-menu">

                                <?php $__currentLoopData = $allService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(Route('service_content',$item->slug)); ?>" class="nav-link">
                                        <?php echo e($item->title); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(url('/about')); ?>" class="nav-link <?php echo e(Request::route()->named('about_page') ? 'active' : ''); ?>">
                                About
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(url('/our-team')); ?>" class="nav-link <?php echo e(Request::route()->named('team_page') ? 'active' : ''); ?>">
                                Our Team
                            </a>
                          
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(url('/blog')); ?>" class="nav-link <?php echo e(Request::route()->named('blog_page') ? 'active' : ''); ?>">
                                Blog
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/contact')); ?>" class="nav-link <?php echo e(Request::route()->named('contact_page') ? 'active' : ''); ?>">
                                Contact
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="#demo" class="nav-link">
                                Demo
                            </a>
                        </li>
                    </ul>
                    <div class="nav-side d-display">
                        <div class="nav-side-item">
                            <div class="search-box">
                                <i class="bx bx-search"></i>
                            </div>
                        </div>
                        <div class="nav-side-item">
                            <div class="get-btn">
                                <a href="<?php echo e(url('/contact')); ?>" class="default-btn btn-bg-two border-radius-50">Get A Quote
                                    <i class="bx bx-chevron-right"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </nav>
        </div>
    </div>
    <div class="side-nav-responsive">
        <div class="container-max">
            <div class="dot-menu">
                <div class="circle-inner">
                    <div class="in-circle circle-one"></div>
                    <div class="in-circle circle-two"></div>
                    <div class="in-circle circle-three"></div>
                </div>
            </div>
            <div class="container">
                <div class="side-nav-inner">
                    <div class="side-nav justify-content-center align-items-center">
                        <div class="side-nav-item nav-side">
                            <div class="search-box">
                                <i class="bx bx-search"></i>
                            </div>
                            <div class="get-btn">
                                <a href="contact.html" class="default-btn btn-bg-two border-radius-50">Get A Quote
                                    <i class="bx bx-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/frontend/layouts/nabvar.blade.php ENDPATH**/ ?>