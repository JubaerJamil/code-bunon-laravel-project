<?php $__env->startSection('forntend_content'); ?>
    <div class="inner-banner">
        <div class="container">
            <div class="inner-title text-center">
                <h3><?php echo e($serviceContent->title); ?></h3>
                <ul>
                    <li>
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li>
                        <i class="bx bx-chevrons-right"></i>
                    </li>
                    <li>Service Details</li>
                </ul>
            </div>
        </div>
        <div class="inner-shape">
            <img src="frontend-asset/images/shape/inner-shape.png" alt="Images">
        </div>
    </div>
    <div class="service-details-area pt-100 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-article">
                        <div class="service-article-img">
                            <img src="<?php echo e(asset($serviceContent->title_image)); ?>" alt="<?php echo e($serviceContent->title); ?>">
                        </div>
                        <div class="service-article-content">
                          
                            <?php echo $serviceContent->content; ?>

                           
                        </div>
                        <div class="service-article-img">
                            <?php if($serviceContent->image): ?>
                            <img src="<?php echo e(asset($serviceContent->image)); ?>" alt="<?php echo e($serviceContent->title); ?>">
                        <?php endif; ?>
                        
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="side-bar-area">
                        <div class="side-bar-widget">
                            <h3 class="title">Our Services</h3>
                            <div class="side-bar-categories">
                                <ul>
                                    <?php $__currentLoopData = $allService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="d-flex justify-content-end">
                                        <i class='fs-5 bx bxs-right-arrow-circle' style="color: rgb(0,113,220); margin-top: 6px;"></i>
                                        <a href="<?php echo e(Route('service_content',$service->slug)); ?>" style="margin-left: -18px;"><?php echo e($service->title); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="side-bar-widget">
                            <h3 class="title">Languages And Frameworks</h3>
                            <ul class="side-bar-widget-tag">
                                <li><a href="#">PHP</a></li>
                                <li><a href="#">Laravel</a></li>
                                <li><a href="#">WordPress</a></li>
                                <li><a href="#">Shopify</a></li>
                                <li><a href="#">Vue Js</a></li>
                                <li><a href="#">Rect Js</a></li>
                                <li><a href="#">Note Js</a></li>
                                <li><a href="#">Javascript</a></li>
                                <li><a href="#">MySql</a></li>
                                <li><a href="#">Bootstrap</a></li>
                                <li><a href="#">jQuery</a></li>
                                <li><a href="#">Ajax</a></li>
                                <li><a href="#">Axios</a></li>
                                <li><a href="#">Css</a></li>
                            </ul>
                        </div>
                        <div class="side-bar-widget">
                            <h3 class="title">Gallery</h3>
                            <ul class="blog-gallery">
                                <li>
                                    <a href="#">
                                        <img src="<?php echo e(asset('frontend-asset/images/blog/blog-small-img1.jpg')); ?>" alt="image">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="<?php echo e(asset('frontend-asset/images/blog/blog-small-img2.jpg')); ?>" alt="image">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="<?php echo e(asset('frontend-asset/images/blog/blog-small-img3.jpg')); ?>" alt="image">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="<?php echo e(asset('frontend-asset/images/blog/blog-small-img4.jpg')); ?>" alt="image">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="<?php echo e(asset('frontend-asset/images/blog/blog-small-img5.jpg')); ?>" alt="image">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="<?php echo e(asset('frontend-asset/images/blog/blog-small-img6.jpg')); ?>" alt="image">
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="side-bar-widget">
                            <h3 class="title">Archive</h3>
                            <div class="side-bar-categories">
                                <ul>
                                    <li>
                                        <div class="line-circle"></div>
                                        <a href="#" >Design<span>[70]</span></a>
                                    </li>
                                    <li>
                                        <div class="line-circle"></div>
                                        <a href="#" >Business<span>[24]</span></a>
                                    </li>
                                    <li>
                                        <div class="line-circle"></div>
                                        <a href="#" >Development<span>[08]</span></a>
                                    </li>
                                    <li>
                                        <div class="line-circle"></div>
                                        <a href="#" >Technology <span>[17]</span></a>
                                    </li>
                                    <li>
                                        <div class="line-circle"></div>
                                        <a href="#" >Startup <span>[20]</span></a>
                                    </li>
                                    <li>
                                        <div class="line-circle"></div>
                                        <a href="#" >Marketing Growth
                                            <span>[13]</span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/frontend/service-details.blade.php ENDPATH**/ ?>