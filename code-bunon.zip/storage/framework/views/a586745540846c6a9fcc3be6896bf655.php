
<?php $__env->startSection('backend_title','Admin Brand Create'); ?>

<?php $__env->startSection('backend_content'); ?>

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-lg-offset-5">
      <div class="card">
          <div class="card-body">
              <h5 class="font-weight-bolder">Service Item Update</h5>
              <div class="row">

                <div class="col-lg-6 col-md-6 col-sm-12 mb-2">
                  <label>Title</label>
                  <input class="form-control" type="text" name="title" placeholder="" value="<?php echo e($services->title); ?>" readonly />
                  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="form-text text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12 mb-2">
                    <label class="form-label" for="icon">Service Icon</label>
                    <input type="text" class="form-control" id="icon" placeholder="Icon code"
                        name="icon" value="<?php echo e($services->icon); ?>" readonly />
                    <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 mb-2">
                    <label class="form-label">Service Content</label>
                    <textarea name="content" class="form-control" id="myContent" cols="35" rows="30" readonly><?php echo e($services->content); ?></textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>



              <div class="col-lg-6 col-md-6 col-sm-12 mb-2 mt-2">
                <div><label class="form-label" for="">Title Image</label></div>
                <img src="<?php echo e(asset($services->title_image)); ?>" alt="Image Preview" id="title_img" class="mt-1 rounded float-start"
                    style="width:320px; max-height: 200px; border: none; outline: none; background: transparent;">
                <?php $__errorArgs = ['title_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12 mb-2 mt-2">
                <div><label class="form-label" for="">Image</label></div>
                <img src="<?php echo e(asset($services->image)); ?>" alt="Image Preview" id="img" class="mt-3 rounded float-start"
                    style="width:320px; max-height: 200px; border: none; outline: none; background: transparent;">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-lg-6 col-md-6 col-sm-12 mt-4">
                <div>
                    <label>Status</label>
                </div>
                <div>

                    <?php if($services->status == 1): ?>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="status1" checked>
                        <label class="form-check-label" for="status1">Active</label>
                    </div>
                    <?php elseif($services->status == 0): ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="status" id="status0" checked>
                            <label class="form-check-label" for="status0">Inactive</label>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

              </div>
              <div class="mt-2">
                <a href="<?php echo e(route('service_List')); ?>" class="btn btn-info">Return List</a>
              </div>
          </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('beackend_scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/backend/service/show.blade.php ENDPATH**/ ?>