<?php $__env->startSection('backend_title', 'Admin Brand List'); ?>

<?php $__env->startSection('backend_content'); ?>

    <div class="my-4 row">
        <div class="col-lg-12 col-md-12 col-12">
            <div class="card">
                <!-- Card header -->
                <div class="pb-0 card-header">
                    <div class="d-lg-flex">
                        <div>
                            <h5 class="mb-0">All Service Item </h5>
                            <p class="mb-0 text-sm">
                            </p>
                        </div>
                        <div class="my-auto mt-4 ms-auto mt-lg-0">
                            <div class="my-auto ms-auto">
                                <a href="<?php echo e(Route('service_create_Page')); ?>" class="me-2 mb-0 btn btn-dark">
                                    <i class="fas fa-plus me-1"></i>
                                    Add new service
                                </a>
                              
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="px-0 pb-0 card-body">
                    <div class="table-responsive">
                        <table class="table table-flush" id="products-list">
                            <thead class="thead-light">
                                <tr>
                                    <th class="fs-6" style="color: black">Sl. No.</th>
                                    <th class="fs-6" style="color: black">Title Image</th>
                                    <th class="fs-6" style="color: black">2nd Image</th>
                                    <th class="fs-6" style="color: black">Icon</th>
                                    <th class="fs-6" style="color: black">Title</th>
                                    <th class="fs-6" style="color: black">Status</th>
                                    <th class="fs-6" style="color: black">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>

                                        <td>
                                            <?php echo e($index + 1); ?>

                                        </td>

                                        <td>
                                            <img src="<?php echo e(asset($item->title_image)); ?>" alt="" width="150" height="100">
                                        </td>

                                        <td>
                                            <img src="<?php echo e(asset($item->image)); ?>" alt="" width="150" height="100">
                                        </td>

                                        <td><?php echo e($item->icon); ?></td>

                                        <td>
                                            <?php echo e($item->title); ?>

                                        </td>

                                        <td>
                                            <?php if($item->status == 1): ?>
                                                <span class="badge badge-success badge-sm">Active</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger badge-sm">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-sm">

                                            <a href="<?php echo e(Route('service_show_Page',$item->id)); ?>" class="mx-3"
                                                data-bs-toggle="tooltip" data-bs-original-title="Edit product">
                                                <i class="fa-solid fa-eye fs-5"></i>
                                            </a>

                                            <a href="<?php echo e(Route('service_edit_Page',$item->id)); ?>" class="mx-3"
                                                data-bs-toggle="tooltip" data-bs-original-title="Edit product">
                                                <i class="fa-solid fa-pen-to-square fs-5"></i>
                                            </a>

                                            <a onclick="return confirm('Are you sure Delete?')"
                                                href="<?php echo e(Route('service_slider_Delete', $item->id)); ?>" data-bs-toggle="tooltip"
                                                data-bs-original-title="Delete product">
                                                <i class="fa-solid fa-trash-can fs-5"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-sm" colspan="3">Data Not Found!!</td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code Bunon\website\code-bunon\resources\views/backend/service/index.blade.php ENDPATH**/ ?>